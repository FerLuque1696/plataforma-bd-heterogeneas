📦 Plataforma de integración de BDs - Ejecución local

1. Haz doble clic en `BDH_Plataform`
2. El script verificará si Python está instalado.
3. Si no lo está, lo descargará automáticamente.
4. Se instalarán los paquetes necesarios.
5. Se abrirá la aplicación en tu navegador.

💡 Requisitos:
- Conexión a Internet (la primera vez)
- Permisos de instalación

Alumno: Fernando Luque Villacorta
Codigo: 000123510
Product Owner: Walter Cueva Chavez