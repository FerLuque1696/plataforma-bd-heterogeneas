# exploracion.py

import streamlit as st
import pandas as pd

def mostrar():
    st.title("Exploración de Tablas y Estructuras")

    if "connections" not in st.session_state or not st.session_state.connections:
        st.warning("Primero debes conectar al menos un motor de base de datos desde la pestaña 'Conexión a Motores'.")
        return

    motores_disponibles = list(st.session_state.connections.keys())

    motor_seleccionado = st.selectbox("Selecciona un motor", motores_disponibles, key="exploracion_motor")

    if motor_seleccionado:
        engine = st.session_state.connections[motor_seleccionado]
        inspector = None

        try:
            from sqlalchemy import inspect
            inspector = inspect(engine)
        except Exception as e:
            st.error(f"No se pudo inspeccionar el motor: {e}")
            return

        tablas = inspector.get_table_names()

        if not tablas:
            st.info("Este motor no contiene tablas.")
            return

        tabla_seleccionada = st.selectbox("Selecciona una tabla", tablas, key="exploracion_tabla")

        if tabla_seleccionada:
            columnas = inspector.get_columns(tabla_seleccionada)
            st.subheader("Estructura de la Tabla")
            estructura_df = pd.DataFrame(columnas)[["name", "type", "nullable"]]
            estructura_df.columns = ["Nombre de Columna", "Tipo de Dato", "¿Puede ser Nulo?"]
            st.dataframe(estructura_df)

            try:
                st.subheader("Contenido de la Tabla")
                query = f"SELECT * FROM {tabla_seleccionada} LIMIT 100"
                df = pd.read_sql(query, engine)
                st.dataframe(df)
            except Exception as e:
                st.warning(f"No se pudo mostrar contenido: {e}")
