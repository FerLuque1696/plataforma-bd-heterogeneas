# pages/sincronizacion.py

import streamlit as st
from utils.sync_logic import sync_universal

def mostrar(df_integrado, motores, columnas_integradas):
    st.header("🔄 Sincronización Universal entre Bases de Datos")
    st.write("Esta sección permite sincronizar la tabla integrada con las bases de datos conectadas.")

    if df_integrado is None or df_integrado.empty:
        st.warning("⚠️ Primero debes integrar los datos antes de sincronizar.")
        return

    if not columnas_integradas:
        st.warning("⚠️ No se encontraron columnas válidas para sincronizar.")
        return

    tabla_destino = st.text_input("Nombre de la tabla destino (debe existir en cada motor)", "clientes")

    if st.button("Iniciar sincronización"):
        with st.spinner("Sincronizando..."):
            resultados = sync_universal(df_integrado, motores, tabla_destino, columnas_integradas)

        st.subheader("📊 Resultados de la sincronización")
        for motor, resultado in resultados.items():
            st.markdown(f"- **{motor}** → {resultado}")
