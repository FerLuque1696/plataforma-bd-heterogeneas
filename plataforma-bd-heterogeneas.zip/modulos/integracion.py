# integracion.py

import streamlit as st
import pandas as pd
import graphviz
from utils.integracion_utils import obtener_columnas_compatibles, integrar_tablas

def mostrar():
    st.title("Integración de Tablas")

    if "connections" not in st.session_state or len(st.session_state.connections) < 2:
        st.warning("Debes conectar al menos dos motores para realizar la integración.")
        return

    motores = list(st.session_state.connections.keys())

    st.subheader("Seleccionar Tablas a Integrar")

    col1, col2 = st.columns(2)
    with col1:
        motor1 = st.selectbox("Motor 1", motores, key="motor1")
        tablas1 = obtener_tablas(motor1)
        tabla1 = st.selectbox("Tabla 1", tablas1, key="tabla1")
    with col2:
        motor2 = st.selectbox("Motor 2", motores, key="motor2")
        tablas2 = obtener_tablas(motor2)
        tabla2 = st.selectbox("Tabla 2", tablas2, key="tabla2")

    if motor1 == motor2 and tabla1 == tabla2:
        st.error("Debes seleccionar tablas distintas.")
        return

    if st.button("Obtener columnas compatibles"):
        columnas_compatibles = obtener_columnas_compatibles(
            st.session_state.connections[motor1], tabla1,
            st.session_state.connections[motor2], tabla2
        )

        if not columnas_compatibles:
            st.warning("No se encontraron columnas compatibles.")
            return

        st.success("Columnas compatibles encontradas.")
        st.write("Columnas coincidentes:", columnas_compatibles)

        with st.expander("Vista previa de unión"):
            df_integrado = integrar_tablas(
                st.session_state.connections[motor1], tabla1,
                st.session_state.connections[motor2], tabla2,
                columnas_compatibles
            )
            st.dataframe(df_integrado.head(100))
            st.session_state["tabla_integrada"] = df_integrado
            st.session_state["columnas_mapeadas"] = columnas_compatibles

        with st.expander("Visualización del mapeo"):
            dot = generar_mapa_columnas(columnas_compatibles, tabla1, tabla2)
            st.graphviz_chart(dot)

def obtener_tablas(motor_alias):
    engine = st.session_state.connections[motor_alias]
    from sqlalchemy import inspect
    inspector = inspect(engine)
    return inspector.get_table_names()

def generar_mapa_columnas(columnas, tabla1, tabla2):
    dot = graphviz.Digraph()
    dot.attr(rankdir="LR")

    with dot.subgraph(name="cluster1") as c1:
        c1.attr(label=tabla1, style='filled', color='lightgrey')
        for col1, _ in columnas:
            c1.node(f"{tabla1}_{col1}", col1)

    with dot.subgraph(name="cluster2") as c2:
        c2.attr(label=tabla2, style='filled', color='lightblue')
        for _, col2 in columnas:
            c2.node(f"{tabla2}_{col2}", col2)

    for col1, col2 in columnas:
        dot.edge(f"{tabla1}_{col1}", f"{tabla2}_{col2}")

    return dot
