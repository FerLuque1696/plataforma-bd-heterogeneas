# utils/sync_logic.py

import pandas as pd
from sqlalchemy import inspect

def sync_universal(df_integrado, motores, tabla_destino, columnas_destino):
    resultados = {}

    for motor, engine in motores.items():
        try:
            insp = inspect(engine)
            if tabla_destino not in insp.get_table_names():
                resultados[motor] = "❌ Tabla destino no existe"
                continue

            # Verificamos columnas reales del destino
            columnas_bd = [col["name"] for col in insp.get_columns(tabla_destino)]

            # Filtramos columnas coincidentes
            columnas_validas = [col for col in columnas_destino if col in columnas_bd]
            if not columnas_validas:
                resultados[motor] = "❌ No hay columnas compatibles"
                continue

            # Verificamos duplicados por clave primaria (asumimos la 1era columna como ID si existe)
            df_bd = pd.read_sql(f"SELECT {', '.join(columnas_validas)} FROM {tabla_destino}", engine)
            df_bd = df_bd.drop_duplicates()

            df_nueva = df_integrado[columnas_validas].drop_duplicates()

            # Si tienen claves comunes, comparamos
            if not df_bd.empty and columnas_validas[0] in df_bd.columns:
                df_merged = pd.merge(df_nueva, df_bd, how="left", on=columnas_validas[0], indicator=True)
                df_final = df_merged[df_merged["_merge"] == "left_only"].drop(columns=["_merge"])
            else:
                df_final = df_nueva

            if df_final.empty:
                resultados[motor] = "🔁 Sin cambios (todo sincronizado)"
            else:
                # Insertar nuevos datos
                df_final.to_sql(tabla_destino, engine, index=False, if_exists="append", method="multi")
                resultados[motor] = f"✅ Insertados: {len(df_final)} nuevos registros"
        except Exception as e:
            resultados[motor] = f"⚠️ Error: {str(e)}"

    return resultados
