import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pytest
from modulos.integracion import generar_mapeo, validar_mapeo

columnas_origen = ['id', 'nombre', 'correo']
columnas_destino_compatibles = ['id', 'nombre', 'correo']
columnas_destino_extra = ['id', 'nombre', 'correo', 'telefono']
columnas_destino_incompatibles = ['codigo', 'direccion', 'fecha']

def test_mapeo_compatible():
    mapeo = generar_mapeo(columnas_origen, columnas_destino_compatibles)
    assert mapeo == {'id': 'id', 'nombre': 'nombre', 'correo': 'correo'}
    validos, errores = validar_mapeo(mapeo, columnas_origen, columnas_destino_compatibles)
    assert validos
    assert len(errores) == 0

def test_mapeo_parcial():
    mapeo = generar_mapeo(columnas_origen, columnas_destino_extra)
    assert mapeo == {'id': 'id', 'nombre': 'nombre', 'correo': 'correo'}
    validos, errores = validar_mapeo(mapeo, columnas_origen, columnas_destino_extra)
    assert validos
    assert len(errores) == 0

def test_mapeo_incompatible():
    mapeo = generar_mapeo(columnas_origen, columnas_destino_incompatibles)
    assert mapeo == {}  # No hay coincidencias
    validos, errores = validar_mapeo(mapeo, columnas_origen, columnas_destino_incompatibles)
    assert not validos
    assert len(errores) == len(columnas_origen)
